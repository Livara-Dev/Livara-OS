LIVARA MOZILLA COMPILER 403 REPAIR

Extract every file in this ZIP over the existing Livara source folder containing
Build-Livara.bat. Replace matching files. Keep the same source folder and Docker
cache volumes. Then run Build-Livara.bat again. Do not delete caches or prune Docker.

This fixes the late compiler dependency handling shown in the supplied log:
Mozilla returned HTTP 403 for chain-of-trust.json. The updated full builder checks
that dependency before editor compilation, downloads and checksum-verifies the
compiler before browser source preparation, and uses verified cached provenance
for the pinned task. Other tasks retain normal download verification.

A persistent network block now stops the early check. Access is still required
from Docker to firefox-ci-tc.services.mozilla.com and
firefoxci.taskcluster-artifacts.net; a source patch cannot change your network.
TLS and SHA-256 checks remain enabled. There is no third-party compiler mirror.

Verified: the full official compiler archive was downloaded and hashed, Clang
22.1.8 executed, and the actual patched Mozilla ArtifactRecord succeeded with
network requests forced to fail with 403. Corrupt provenance was rejected.
222 Python tests passed (one expected skip), plus 15 editor Node tests and
desktop contract checks in the Linux controller image. GitHub source checks passed.
This is dependency recovery, not proof of a full browser build, native Windows
execution or a bootable ISO. No ISO or compiled browser is in this repair ZIP.

Source: https://github.com/Livara-Dev/Livara-OS
Details: docs/browser-toolchain-recovery.md
